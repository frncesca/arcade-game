# Play time!
Let's play against giant bugs.

## Install
Download and open the index.html file with your browser.

## Play
Use your keyboard keys for up, down, left and right to move the player accordingly.

## Win
Your player should reach the water and avoid the bugs in order to win.
* Win when you reach the water
* Die when you cross a bug

## Credits
Initial files from Udacity for the Udacity Arcade Game Clone Project. I've only edited the app.js file (See my comments marked as "F: ").